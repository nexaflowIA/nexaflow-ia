const year = document.getElementById('year');
if (year) year.textContent = new Date().getFullYear();
const form = document.getElementById('chat-form');
const question = document.getElementById('question');
const messages = document.getElementById('messages');
const status = document.getElementById('chat-status');
function addMessage(text, kind) {
  const el = document.createElement('div');
  el.className = `message ${kind}`;
  el.textContent = text;
  messages.appendChild(el);
  messages.scrollTop = messages.scrollHeight;
  return el;
}
if (form) form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const prompt = question.value.trim();
  if (!prompt) return;
  addMessage(prompt, 'user');
  question.value = '';
  const waiting = addMessage('Estoy preparando la respuesta…', 'bot');
  status.textContent = 'Conectando con el asistente…';
  const button = form.querySelector('button');
  button.disabled = true;
  try {
    const response = await fetch('/.netlify/functions/chat', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: prompt })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || 'No se pudo obtener respuesta.');
    waiting.textContent = data.reply || 'No he recibido una respuesta. Inténtalo de nuevo.';
    status.textContent = 'Respuesta recibida.';
  } catch (error) {
    waiting.textContent = `No se ha podido conectar con la IA. ${error.message || 'Comprueba la función de Netlify y la variable OPENAI_API_KEY.'}`;
    status.textContent = 'Comprueba el despliegue de la función y la variable OPENAI_API_KEY en Netlify.';
  } finally {
    button.disabled = false;
    question.focus();
  }
});
