# NexaFlow IA
Panel en español para gestionar clientes, tareas, proyectos y agenda, con asistente de IA mediante una función de Netlify.

## Publicar
1. Sube el contenido de esta carpeta al repositorio existente `nexaflowIA/nexaflow-ia` (descomprime el ZIP antes de subirlo a GitHub).
2. Conecta ese repositorio a Netlify o haz que el sitio de Netlify existente despliegue desde ese repositorio.
3. En las variables de entorno de Netlify, configura `OPENAI_API_KEY` como secreto. No la escribas en los archivos ni la envíes por chat.
4. Opcionalmente configura `OPENAI_MODEL` con un modelo disponible para tu cuenta. Por defecto se usa `gpt-4.1-mini`.
5. Vuelve a desplegar para que la función se publique.

## Importante
Esta versión guarda clientes, tareas, proyectos y agenda en el almacenamiento local del navegador; no sincroniza entre dispositivos o usuarios y los datos pueden perderse al borrar los datos del navegador. No guardes información sensible. Para uso real multiusuario se necesita autenticación y una base de datos.
