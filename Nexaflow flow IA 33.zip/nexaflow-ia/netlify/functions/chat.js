exports.handler = async (event) => {
  const headers = { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" };
  if (event.httpMethod !== "POST") return { statusCode: 405, headers, body: JSON.stringify({ error: "Método no permitido. Usa POST." }) };
  if (!process.env.OPENAI_API_KEY) return { statusCode: 500, headers, body: JSON.stringify({ error: "Falta configurar OPENAI_API_KEY en las variables de entorno de Netlify." }) };
  let p; try { p = JSON.parse(event.body || "{}"); } catch { return { statusCode: 400, headers, body: JSON.stringify({ error: "La solicitud no contiene JSON válido." }) }; }
  const message = typeof p.message === "string" ? p.message.trim() : "";
  if (!message) return { statusCode: 400, headers, body: JSON.stringify({ error: "Escribe un mensaje para el asistente." }) };
  if (message.length > 8000) return { statusCode: 413, headers, body: JSON.stringify({ error: "El mensaje es demasiado largo." }) };
  const history = Array.isArray(p.history) ? p.history.slice(-8).map(m => ({ role: m && m.role === "assistant" ? "assistant" : "user", content: String(m && m.text || "").slice(0, 4000) })) : [];
  try {
    const r = await fetch("https://api.openai.com/v1/responses", { method: "POST", headers: { "Authorization": "Bearer " + process.env.OPENAI_API_KEY, "Content-Type": "application/json" }, body: JSON.stringify({ model: process.env.OPENAI_MODEL || "gpt-4.1-mini", instructions: "Eres el asistente de NexaFlow IA, una herramienta empresarial en español. Responde siempre en español claro y con tono profesional y cercano. Ayuda con organización de clientes, tareas, proyectos, agenda, productividad y comunicación comercial. No afirmes que has guardado o cambiado datos en la aplicación.", input: [...history.map(m => ({ role: m.role, content: m.content })), { role: "user", content: message }], max_output_tokens: 700 }) });
    const data = await r.json();
    if (!r.ok) { console.error("OpenAI API error", r.status, data && data.error && data.error.message); return { statusCode: 502, headers, body: JSON.stringify({ error: "El proveedor de IA no ha podido responder. Revisa la clave y los permisos de la API en Netlify." }) }; }
    const reply = (data.output || []).flatMap(x => x.content || []).filter(x => x.type === "output_text").map(x => x.text).join("\n").trim();
    return { statusCode: 200, headers, body: JSON.stringify({ reply: reply || "No he podido generar una respuesta. Inténtalo de nuevo." }) };
  } catch (e) { console.error("Chat function error", e && e.message); return { statusCode: 502, headers, body: JSON.stringify({ error: "No se ha podido contactar con el servicio de IA. Inténtalo más tarde." }) }; }
};
